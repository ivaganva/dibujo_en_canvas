var d = document.getElementById("dibujo");
var lienzo = d.getContext("2d");
var linea = 15;
var linea2 = 15; 
var linea3 = 15; 
var linea4 = 15;
var linea5 = 15;
var l = 0;
var yi, xf, xi, yf;
var color_linea = "#2471A3";
var color_linea2 = "#154360";
var color_linea3 = "#FFC300";
var color_linea4 = "#FF5733";
var color_linea5 = "gray";
 

for (l = 0; l < linea; l++) 
{
    yi = 10 * l;
    xf = 150 - (10 * l);
    dibujarLinea(color_linea, 150, yi, xf, 150);
}

for (l = 0; l < linea; l++)
{
    yi = 10 * l;
    xf = 150 + (l * 10); 
    dibujarLinea(color_linea2, 150, yi, xf, 150);
}


for (l = 0; l < linea; l++)
{
    xi = 10 * l;
    yf = 150 + (l * 10); 
    dibujarLinea(color_linea3, xi, 150, 150, yf);
}

for (l = 0; l < linea; l++)
{
    xi = 300 - (l * 10);
    yf =  150 + (l * 10);
    dibujarLinea(color_linea4, xi, 150, 150, yf);
}
/*
dibujarLinea(color_linea,300, 150, 150, 160);
dibujarLinea(color_linea,290, 150, 150, 170);
dibujarLinea(color_linea,280, 150, 150, 180);
dibujarLinea(color_linea,270, 150, 150, 190);
dibujarLinea(color_linea,40, 150, 150, 200);
dibujarLinea(color_linea,50, 150, 150, 210);
*/

dibujarLinea(color_linea, 0, 150, 300, 150);
dibujarLinea(color_linea, 150, 0, 150, 300);

function dibujarLinea(color, xinicial, yinicial, xfinal, yfinal) 
{
    lienzo.beginPath();
    lienzo.strokeStyle = color;
    lienzo.moveTo(xinicial, yinicial);
    lienzo.lineTo(xfinal, yfinal);
    lienzo.stroke();
    lienzo.closePath();
}
